import json
import psycopg2

def lambda_handler(event, context):
  """Inserts data into an RDS PostgreSQL database instance.

  Args:
    event: The Lambda event.
    context: The Lambda context.

  Returns:
    A response object.
  """
  print('event data', event)

  # Get the database connection URL.
  #   database_url = os.environ['postgres://postgres:postgres@database-test.cfsrg6viclx3.us-east-1.rds.amazonaws.com:9876/cloud_services']
  #   conn = psycopg2.connect(database_url)

  try:

    body_data = json.loads(event['body'])

    conn = psycopg2.connect(
      dbname='',
      user='',
      password='',
      host='',
      port='',
      sslmode='require'
      )

    # Create a cursor.
    cur = conn.cursor()

    query = 'INSERT INTO public."estudiante" (nombre, apellido, fecha_nacimiento, direccion, correo_electronico, carrera) VALUES ( %s,%s,%s,%s,%s,%s)'
    data = (body_data['nombre'], body_data['apellido'], body_data['fecha_nacimiento'], body_data['direccion'], body_data['correo_electronico'], body_data['carrera'])

    print(query, data)
    # Insert the data into the database.
    cur.execute(query, data)

    # Commit the changes.
    conn.commit()

    # Close the cursor and connection.
    cur.close()
    conn.close()

    return {
      'statusCode': 200,
      'body': json.dumps('Data inserted successfully.')
    }
  except Exception as err:
    print(err)
    return {
      'statusCode': 400,
      'body': json.dumps(str(err))
    }
