import pkg from 'pg';
const { Client } = pkg;

export async function lambdaHandler(event, context) {
    console.log('event data', event);

    try {
        const bodyData = JSON.parse(event.body);

        const client = new Client({
            user: 'Nexa',
            host: 'awseb-e-ezmi99dmer-stack-awsebrdsdatabase-encsvsuciqcs.co3eojukclvm.us-east-1.rds.amazonaws.com',
            database: 'ebdb',
            password: 'Nexa12345',
            port: 9876,
            ssl: { rejectUnauthorized: false }
        });

        await client.connect();

        const query = 'INSERT INTO public."estudiante" (nombre, apellido, fecha_nacimiento, direccion, correo_electronico, carrera) VALUES ($1, $2, $3, $4, $5, $6)';
        const values = [
            bodyData.nombre,
            bodyData.apellido,
            bodyData.fecha_nacimiento,
            bodyData.direccion,
            bodyData.correo_electronico,
            bodyData.carrera
        ];

        console.log(query, values);
        await client.query(query, values);

        await client.end();

        return {
            statusCode: 200,
            body: JSON.stringify('Data inserted successfully.')
        };
    } catch (err) {
        console.error(err);
        return {
            statusCode: 400,
            body: JSON.stringify(err.message)
        };
    }
}
